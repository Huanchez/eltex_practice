#!/bin/bash

# Path to log and conf file
CONF_FILE="observer.conf"
LOG_FILE="observer.log"

if [[ ! -f "$CONF_FILE" ]]; then
    echo "Конфигурационный файл не найден: $CONF_FILE"
    exit 1
fi

if [[ ! -f "$LOG_FILE" ]]; then
    touch "$LOG_FILE"
    echo "$LOG_FILE создан" >> "$LOG_FILE"
fi

# Check with /proc
check_process_via_proc() {
    local script_name="$1"
    
    for pid_dir in /proc/[0-9]*/; do
        if [[ -f "${pid_dir}cmdline" ]]; then
            # Читаем cmdline и ищем имя скрипта
            if grep -q "$script_name" "${pid_dir}cmdline" 2>/dev/null; then
                return 0 # Процесс найден
            fi
        fi
    done
    return 1 # Процесс не найден
}

# Read conf file
while IFS= read -r script; do
    script_name=$(basename "$script")
    # Checking script in the list of working process via /proc
    if ! check_process_via_proc "$script_name"; then
        nohup bash "$script" > /dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Cкрипт $script был перезапущен" >> "$LOG_FILE"
    fi

done < "$CONF_FILE"
